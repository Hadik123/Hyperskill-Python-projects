print(input())
print(input())
print(input())
