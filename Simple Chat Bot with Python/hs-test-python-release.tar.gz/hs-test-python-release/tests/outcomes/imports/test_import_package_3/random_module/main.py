import in1.in2.main2
import in1.file
print(in1.in2.main2.x + in1.file.y)
