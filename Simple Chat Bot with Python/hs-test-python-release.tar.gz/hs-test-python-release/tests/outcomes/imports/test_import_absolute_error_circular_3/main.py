import main2

if __name__ == '__main__':
    print(main2.x)
