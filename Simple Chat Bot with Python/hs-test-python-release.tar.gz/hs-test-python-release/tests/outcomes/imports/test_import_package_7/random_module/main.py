from .in1.in2 import main2
from .in1 import file
print(main2.x + file.y)
