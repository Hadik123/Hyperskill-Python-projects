while True:
    print("Line1")
    print("Line2")
    print("Line3")
    print("Line4")
    print("Line5")
    print("Line6")
    print("Line7")
