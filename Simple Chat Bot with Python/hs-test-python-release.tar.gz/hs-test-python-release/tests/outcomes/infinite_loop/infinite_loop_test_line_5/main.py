while True:
    print("Line1")
    print("Line2")
    print("Line3")
    print("Line4")
    print("Line5")
