print(123)
try:
    print(0 / 0)
except ArithmeticError:
    print(0 / 0)
