print(input(), end='')
