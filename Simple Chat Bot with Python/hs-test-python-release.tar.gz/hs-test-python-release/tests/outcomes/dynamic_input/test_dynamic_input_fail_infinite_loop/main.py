while True:
    print(input())
