print("Server started!")
print("S1: " + input())
