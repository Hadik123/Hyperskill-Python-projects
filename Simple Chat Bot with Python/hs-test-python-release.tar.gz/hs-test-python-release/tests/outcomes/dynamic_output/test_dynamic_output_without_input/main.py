print('Print x and y: ', end='')
print('123 456')
print('Another num:')
