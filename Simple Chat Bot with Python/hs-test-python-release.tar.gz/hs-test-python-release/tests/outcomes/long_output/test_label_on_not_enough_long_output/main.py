for i in range(250):
    print(f"A {i} line")
